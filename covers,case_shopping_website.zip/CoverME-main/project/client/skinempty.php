<?php require("head.inc.php") ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Skins » dbrand</title>
    <!-- <link rel="stylesheet" href="styleop.css"> -->
    <link rel="stylesheet" href="style_L_-_Copy_-_Copy.css">
</head>
<body style="padding: 0;margin: 0;">
    <div class="cartt" style ="margin-bottom: 0; background-color: black;color: #afafaf;border-bottom: 5px solid #ffbb00;">Skins</div>
 
    <main style=" height: 80vh; opacity: .7;  background-image: url(beck.png);" >
        <!-- <a onclick="window.history.back() " style="cursor: pointer;
        margin: 1rem; background-color: #ffbb00; margin-top:2rem; padding:1rem; position: absolute; left: 5rem; box-shadow: rgba(0, 0, 0, 0.19) 0px 10px 20px, rgba(0, 0, 0, 0.23) 0px 6px 6px;border-radius: 5px;color: #1b1b1b;" >< Back to Shop</a> -->
    
        <div style="display: flex; align-items: center; flex-direction: column; height: 100%;">
            <h1 style="font-size: 2rem; margin-top:10rem;">There are no skins available.</h2>
            <div  style="margin-top: 2rem; background-color: #ffbb00; height: .1vh;width: 70vh;" class="seprater"></div>
            <h2 style="margin-top: 2rem;font-size: 1.3rem; margin-bottom: 2rem; ">It appears that thier are no skins available. We will add new skins soon for this item.</h2>
            <a onclick="window.history.back() " style="  cursor: pointer;
        margin: 1rem; background-color: #ffbb00; margin-top:2rem; padding:1rem; left: 1rem; box-shadow: rgba(0, 0, 0, 0.19) 0px 10px 20px, rgba(0, 0, 0, 0.23) 0px 6px 6px;border-radius: 5px;color: #1b1b1b;">< Back to Shop</a>
        </div>
</main>
<article>
    
    <div class="seprater"></div>
    <nav style="font-family: 'Roboto Condensed', sans-serif; background-color: #1b1b1b;">
        <div style="display: flex; align-items: center; color: #858585; padding-left: 1rem;"><a href="dash.php"><img  src="home_black_24dp.svg" alt=""></a><a style="margin-left: .25rem;margin-right: .25rem;" href="dash.php">Home</a>/<a style="  color: gray;margin-left: .25rem;margin-right: .25rem;" href="skins.php">Register</a></div>
    </nav>
    <div class="seprater"></div>
    <nav style="padding-left:3rem;color: #858585;background-color: #1b1b1b;">dbrand: All rights reserved</nav>
    </article>

</body>

</html>